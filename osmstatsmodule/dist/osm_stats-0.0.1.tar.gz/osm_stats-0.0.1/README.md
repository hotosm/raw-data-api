# OSM Stats Module

## Local Install

Navigate to module directory and hit :

```python setup.py install```